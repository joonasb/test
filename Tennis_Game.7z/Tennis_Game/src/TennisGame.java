
public class TennisGame {
	
	private int p1;
	private int p2;
	private int scoreFlag;
	
	public TennisGame() {
		// TO BE IMPLEMENTED
		System.out.println("I am a constructor");
		
	}

	public String getScore() {
		System.out.println("I am method for displaying score");
		System.out.println("Here is the format of the scores: player1Score - player2Score");
		// Here is the format of the scores: "player1Score - player2Score"
		// "0 - 0"
		// "15 - 15"
		// "30 - 30"
		// "deuce"
		// "15 - 0", "0 - 15"
		// "30 - 0", "0 - 30"
		// "40 - 0", "0 - 40"
		// "30 - 15", "15 - 30"
		// "40 - 15", "15 - 40"
		// "advantage player1"
		// "advantage player2"
		// "game player1"
		// "game player2"

		// TO BE IMPLEMENTED
		if(p1 >= 3 && p2 >= 3) {
			if (Math.abs(p1 - p2) >= 2) {
				return 0;
			}
		}
		
		return "";
	}
}
