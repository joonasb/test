
public class TennisGameException extends Exception {

}
