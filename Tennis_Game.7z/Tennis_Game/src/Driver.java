
public class Driver {
	
	private String player1;
	private String player2;
	
	public Driver(Driver player1, Driver player2) {
		this.player1 = player1;
		this.player2 = player2;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Driver("James", "John");
		TennisGame play = new TennisGame();
		play.getScore();
	}

}
